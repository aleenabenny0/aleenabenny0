"""Generates the script-style SVG artwork for Aleena's GitHub profile README.

Edit the text below, then run:  python tools/gen.py assets
"""
import base64, io, os, sys
from fontTools.ttLib import TTFont
from fontTools import subset as ftsubset

FONTDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
OUT = sys.argv[1] if len(sys.argv) > 1 else "assets"
os.makedirs(OUT, exist_ok=True)

# ---- palette -------------------------------------------------------------
TEAL, WINE, OLIVE, BROWN, AMBER = "#43808C", "#9F194C", "#476827", "#493D31", "#C3761D"
IVORY = "#FBF7EF"
CREAM = "#F3EBDD"
TINT = {TEAL: "#EEF4F4", WINE: "#F8EEF1", OLIVE: "#F1F4EA", AMBER: "#FAF0E3"}

# key: (css family, weight, style, file, local fallback family for previews)
FONTS = {
    "script": ("Great Vibes", 400, "normal", "GreatVibes.ttf"),
    "serif":  ("Cormorant Garamond", 500, "normal", "Cormorant-Medium.ttf"),
    "bold":   ("Cormorant Garamond", 700, "normal", "Cormorant-Bold.ttf"),
    "italic": ("Cormorant Garamond", 500, "italic", "Cormorant-MediumItalic.ttf"),
}
_tt = {k: TTFont(os.path.join(FONTDIR, v[3])) for k, v in FONTS.items()}


def measure(s, font, size, spacing=0):
    f = _tt[font]
    cmap = f.getBestCmap(); hmtx = f["hmtx"]; upm = f["head"].unitsPerEm
    w = sum(hmtx[cmap[ord(c)]][0] if ord(c) in cmap else upm * 0.5 for c in s)
    extra = s.count(" ") * size * 0.16 if font == "script" else 0
    return w * size / upm + spacing * max(len(s) - 1, 0) + extra


def wrap(s, font, size, maxw):
    lines, cur = [], ""
    for wd in s.split():
        t = (cur + " " + wd).strip()
        if measure(t, font, size) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur); cur = wd
    return lines + ([cur] if cur else [])


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class SVG:
    def __init__(self, w, h, title=""):
        self.w, self.h, self.title = w, h, title
        self.parts, self.css = [], []
        self.chars = {k: set() for k in FONTS}

    def add(self, s):
        self.parts.append(s)

    def text(self, x, y, s, font="serif", size=22, fill=BROWN, anchor="start", spacing=0, extra=""):
        fam, wt, st, _ = FONTS[font]
        self.chars[font].update(s)
        fb = "'Cormorant Garamond Light', serif" if fam.startswith("Cormorant") else "cursive"
        ls = f' letter-spacing="{spacing}"' if spacing else ""
        if font == "script" and " " in s:
            # Script faces have a very narrow space, so place each word explicitly.
            total = measure(s, font, size)
            x0 = x - (total / 2 if anchor == "middle" else total if anchor == "end" else 0)
            for wd in s.split(" "):
                self.text(x0, y, wd, font, size, fill, "start", spacing, extra)
                x0 += measure(wd + " ", font, size)
            return
        self.add(f'<text x="{x:.1f}" y="{y:.1f}" font-family="\'{fam}\', {fb}" font-weight="{wt}" '
                 f'font-style="{st}" font-size="{size}" fill="{fill}" text-anchor="{anchor}"{ls} {extra}>{esc(s)}</text>')

    def caps(self, x, y, s, size=15, fill=BROWN, anchor="start", spacing=2.6, font="bold"):
        """Letter-spaced capitals, used like small caps."""
        self.text(x + (spacing / 2 if anchor == "middle" else 0), y, s.upper(), font=font, size=size,
                  fill=fill, anchor=anchor, spacing=spacing)

    def _font_css(self):
        out = []
        for key, (fam, wt, st, file) in FONTS.items():
            if not self.chars[key]:
                continue
            opts = ftsubset.Options(); opts.flavor = "woff2"; opts.layout_features = ["*"]
            f = TTFont(os.path.join(FONTDIR, file))
            sub = ftsubset.Subsetter(opts)
            sub.populate(text="".join(self.chars[key]) + " ")
            sub.subset(f)
            buf = io.BytesIO(); f.flavor = "woff2"; f.save(buf)
            b64 = base64.b64encode(buf.getvalue()).decode()
            out.append(f"@font-face{{font-family:'{fam}';font-weight:{wt};font-style:{st};"
                       f"src:url(data:font/woff2;base64,{b64}) format('woff2')}}")
        return "".join(out)

    def save(self, name):
        css = self._font_css() + "".join(self.css)
        css += "@media (prefers-reduced-motion: reduce){*{animation:none!important}}"
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" '
               f'width="{self.w}" height="{self.h}" role="img"><title>{esc(self.title)}</title>'
               f'<defs><style>{css}</style></defs>' + "".join(self.parts) + "</svg>")
        path = os.path.join(OUT, name)
        with open(path, "w") as fh:
            fh.write(svg)
        return path


ANIM = """
.fade{animation:fade 1.4s ease-out both}
.fade2{animation:fade 1.4s ease-out .35s both}
.fade3{animation:fade 1.4s ease-out .7s both}
@keyframes fade{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.rule{stroke-dasharray:1400;animation:rule 2s ease-out .2s backwards}
@keyframes rule{from{stroke-dashoffset:1400}to{stroke-dashoffset:0}}
.glint{animation:glint 3.6s ease-in-out infinite;transform-box:fill-box;transform-origin:center}
@keyframes glint{0%,100%{opacity:.35;transform:scale(.8)}50%{opacity:1;transform:scale(1)}}
.drift{animation:drift 5s ease-in-out infinite}
@keyframes drift{0%,100%{transform:translate(0,0)}50%{transform:translate(5px,-5px)}}
"""


# ---- ornaments -----------------------------------------------------------
def diamond(cx, cy, r, color, cls=""):
    c = f' class="{cls}"' if cls else ""
    return f'<path{c} d="M{cx},{cy - r} L{cx + r},{cy} L{cx},{cy + r} L{cx - r},{cy} Z" fill="{color}"/>'


def flourish(cx, cy, w, color=AMBER, center=WINE, cls="rule"):
    """Thin rule that tapers into curls, with a diamond in the middle."""
    h = w / 2
    d = (f"M{cx - h},{cy} C{cx - h + 30},{cy - 9} {cx - h + 60},{cy + 7} {cx - 22},{cy} "
         f"M{cx + 22},{cy} C{cx + h - 60},{cy + 7} {cx + h - 30},{cy - 9} {cx + h},{cy}")
    curl = (f"M{cx - h},{cy} c-8,-6 -14,2 -8,6 c4,3 9,-1 6,-4 "
            f"M{cx + h},{cy} c8,-6 14,2 8,6 c-4,3 -9,-1 -6,-4")
    return (f'<path class="{cls}" d="{d}" fill="none" stroke="{color}" stroke-width="1.4" stroke-linecap="round"/>'
            f'<path d="{curl}" fill="none" stroke="{color}" stroke-width="1.2" stroke-linecap="round"/>'
            + diamond(cx - 12, cy, 3, color) + diamond(cx, cy, 5.5, center) + diamond(cx + 12, cy, 3, color))


def frame(svg, w, h, fill=IVORY, outer=BROWN, inner=AMBER, corners=True):
    svg.add(f'<rect x="1.5" y="1.5" width="{w - 3}" height="{h - 3}" rx="3" fill="{fill}" stroke="{outer}" stroke-width="1.4"/>')
    svg.add(f'<rect x="9" y="9" width="{w - 18}" height="{h - 18}" rx="2" fill="none" stroke="{inner}" stroke-width="0.9" stroke-opacity="0.8"/>')
    if corners:
        for x, y in [(9, 9), (w - 9, 9), (9, h - 9), (w - 9, h - 9)]:
            svg.add(f'<circle cx="{x}" cy="{y}" r="6" fill="{fill}"/>' + diamond(x, y, 4, inner))


def note(cx, cy, s, color):
    return (f'<g fill="{color}" stroke="{color}" stroke-width="1.6" stroke-linecap="round">'
            f'<ellipse cx="{cx}" cy="{cy}" rx="{6 * s}" ry="{4.2 * s}" transform="rotate(-20 {cx} {cy})" stroke="none"/>'
            f'<path d="M{cx + 5.3 * s},{cy - 1 * s} L{cx + 5.3 * s},{cy - 24 * s} Q{cx + 12 * s},{cy - 18 * s} {cx + 14 * s},{cy - 10 * s}" fill="none"/></g>')


def piano(x, y, w, h, color=BROWN):
    out = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" fill="#FFFDF9" stroke="{color}" stroke-width="1.6"/>'
    n = 7
    for i in range(1, n):
        xx = x + i * w / n
        out += f'<line x1="{xx:.1f}" y1="{y}" x2="{xx:.1f}" y2="{y + h}" stroke="{color}" stroke-width="1.1"/>'
    for i in [1, 2, 4, 5, 6]:
        xx = x + i * w / n - w / n * 0.28
        out += f'<rect x="{xx:.1f}" y="{y}" width="{w / n * 0.56:.1f}" height="{h * 0.58:.1f}" rx="1.5" fill="{color}"/>'
    return out


def plane(cx, cy, s, color):
    pts = [(-30, 6), (30, -14), (-6, 16), (-12, 30), (-16, 12)]
    d = "M" + " L".join(f"{cx + a * s:.1f},{cy + b * s:.1f}" for a, b in pts) + " Z"
    return (f'<path d="{d}" fill="{TINT[color]}" stroke="{color}" stroke-width="1.6" stroke-linejoin="round"/>'
            f'<path d="M{cx + 30 * s:.1f},{cy - 14 * s:.1f} L{cx - 16 * s:.1f},{cy + 12 * s:.1f}" stroke="{color}" stroke-width="1.3"/>')


def magnifier(cx, cy, r, color):
    return (f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="#FFFDF9" stroke="{color}" stroke-width="2"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{r - 6}" fill="none" stroke="{color}" stroke-width="0.8" stroke-opacity="0.5"/>'
            f'<path d="M{cx + r * 0.72:.1f},{cy + r * 0.72:.1f} L{cx + r * 1.5:.1f},{cy + r * 1.5:.1f}" stroke="{BROWN}" stroke-width="6" stroke-linecap="round"/>'
            f'<path d="M{cx - r * 0.42:.1f},{cy + r * 0.02:.1f} L{cx - r * 0.1:.1f},{cy + r * 0.34:.1f} L{cx + r * 0.46:.1f},{cy - r * 0.32:.1f}" '
            f'fill="none" stroke="{OLIVE}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>')


# =========================================================================
# CONTENT — edit here
# =========================================================================
NAME = "Aleena Benny"
TITLE_LINE = "AI Engineer  ·  LLM Agents  ·  Evaluation"
TAGLINE = "I build AI systems that have to prove they work."
DETAIL = "B.S. Computer Science, UNC Charlotte  ·  Raleigh, North Carolina"
OPEN_TO = "Open to AI Engineer, Forward Deployed Engineer & Software Engineer roles"

ABOUT = [
    (AMBER, "Computer Science graduate of UNC Charlotte, with a concentration in AI, Robotics & Gaming and a minor in Security & Intelligence Studies."),
    (TEAL, "I design LLM agents and retrieval pipelines, and the evaluation systems that hold them accountable."),
    (OLIVE, "Two government technology internships have shaped my focus: AI that makes public services more reliable."),
    (WINE, "AWS Certified AI Practitioner and AWS Certified Cloud Practitioner."),
]
CURRENTLY = "Refining Agent Evals and seeking a full-time role in AI engineering."
OUTSIDE = "Piano, which led me to build Arranger."

HEADS = [("about", "About"), ("built", "Selected Work"), ("worked", "Experience"),
         ("toolbox", "Toolkit"), ("snake", "Contributions")]

PROJECTS = [
    dict(key="agent-evals", title="Agent Evals", sub="LLM Evaluation Platform", color=TEAL, icon="mag",
         tag="Grades AI agents against testable acceptance criteria and flags when they misbehave in production.",
         stats=[("+37 pts", "over closed-book baseline"), ("287", "test cases"), ("2 of 2", "hidden faults detected")],
         stack="Python · Claude API · RAG · LLM-as-Judge · PostgreSQL · GitHub Actions"),
    dict(key="arranger", title="Arranger", sub="MIDI to Playable Piano Sheet Music", color=AMBER, icon="piano",
         tag="A LangGraph agent drafts two-hand arrangements; a deterministic verifier checks and repairs every one.",
         stats=[("14 / 20", "playable (baseline: 6 / 20)"), ("7 nodes", "LangGraph agent"), ("≤ 4", "repair rounds per draft")],
         stack="Python · LangGraph · Claude API · FastAPI · PostgreSQL"),
    dict(key="aeropredict", title="AeroPredict", sub="Flight Delay Prediction", color=OLIVE, icon="plane",
         tag="Predicts flight delays from historical flight data and live weather feeds, served as containerized microservices.",
         stats=[("7M+", "flight records"), ("2", "live weather APIs"), ("AWS EC2", "Docker & Kubernetes")],
         stack="Python · Flask · React · scikit-learn · Docker · Kubernetes"),
]

JOBS = [
    ("2024", "UNC Charlotte", "Undergraduate Research Assistant", "Sensor-log parsing aligned to the millisecond", AMBER),
    ("2024 – 2025", "UNC Charlotte", "Communication Consultant & TA", "35+ consultations on technical projects", WINE),
    ("2025", "City of Raleigh", "IT Data & Integrations Intern", "Crash-risk method across 300,000+ records", OLIVE),
    ("2026", "NC Dept. of IT", "Software QA Analyst Intern", "MCP server work, AI output evaluation, z/OS testing", TEAL),
    ("2026 – Present", "DocsGPT", "Open Source Contributor", "Two merged parser pull requests", AMBER),
]

GROUPS = [
    ("AI", TEAL, ["LLM Agents", "RAG", "Tool Calling", "MCP", "Embeddings", "Vector Databases", "LLM Evaluation", "Claude API", "LangGraph"]),
    ("Engineering", WINE, ["Python", "TypeScript", "JavaScript", "SQL", "FastAPI", "Flask", "React"]),
    ("Infrastructure", OLIVE, ["AWS", "Docker", "Kubernetes", "PostgreSQL", "GitHub Actions", "Git"]),
]


# =========================================================================
# ARTWORK
# =========================================================================
def header():
    W, H = 900, 380
    s = SVG(W, H, f"{NAME}. {TITLE_LINE}. {TAGLINE} {OPEN_TO}.")
    s.css.append(ANIM)
    frame(s, W, H)
    cx = W / 2
    s.add('<g class="fade">'); s.caps(cx, 66, TITLE_LINE.replace("  ", " "), size=15, fill=TEAL, anchor="middle", spacing=3.2); s.add("</g>")
    s.add('<g class="fade">'); s.text(cx, 168, NAME, font="script", size=112, fill=BROWN, anchor="middle"); s.add("</g>")
    s.add(flourish(cx, 214, 420))
    s.add('<g class="fade2">'); s.text(cx, 264, TAGLINE, font="italic", size=31, fill=BROWN, anchor="middle"); s.add("</g>")
    s.add('<g class="fade2">'); s.text(cx, 298, DETAIL, size=20, fill=BROWN, anchor="middle", extra='opacity="0.78"'); s.add("</g>")
    s.add('<g class="fade3">'); s.caps(cx, 340, OPEN_TO, size=12.5, fill=WINE, anchor="middle", spacing=2.2); s.add("</g>")
    # quiet accents
    s.add(f'<g opacity="0.85">{note(92, 140, 1.0, AMBER)}{note(118, 112, 0.75, TEAL)}</g>')
    s.add(diamond(808, 120, 6, OLIVE, "glint") + diamond(830, 146, 4, AMBER, "glint") + diamond(786, 150, 3.5, WINE, "glint"))
    return s.save("header.svg")


def heading(key, label, dark):
    W, H = 900, 96
    s = SVG(W, H, label)
    s.css.append(ANIM)
    ink = CREAM if dark else BROWN
    s.text(14, 68, label, font="script", size=64, fill=ink)
    x0 = 14 + measure(label, "script", 64) + 26
    s.add(f'<line class="rule" x1="{x0}" y1="58" x2="{W - 30}" y2="58" stroke="{AMBER}" stroke-width="1.3"/>')
    s.add(diamond(W - 20, 58, 5, WINE))
    return s.save(f"h-{key}-{'dark' if dark else 'light'}.svg")


def about():
    W = 900
    size, maxw = 23, 520
    layout, y = [], 66
    for c, b in ABOUT:
        ls = wrap(b, "serif", size, maxw)
        layout.append((c, ls, y)); y += len(ls) * 30 + 18
    H = max(int(y + 20), 330)
    s = SVG(W, H, "About: " + " ".join(b for _, b in ABOUT) + f" Currently: {CURRENTLY} Outside of work: {OUTSIDE}")
    s.css.append(ANIM)
    frame(s, W, H)
    for c, ls, yy in layout:
        s.add(diamond(54, yy - 7, 5, c))
        for j, ln in enumerate(ls):
            s.text(76, yy + j * 30, ln, size=size)
    # side panel
    px, py, pw = 640, 40, 228
    s.add(f'<line x1="{px - 18}" y1="{py}" x2="{px - 18}" y2="{H - 40}" stroke="{AMBER}" stroke-width="1"/>')
    s.text(px, py + 40, "Currently", font="script", size=40, fill=WINE)
    yy = py + 74
    for ln in wrap(CURRENTLY, "italic", 21, pw):
        s.text(px, yy, ln, font="italic", size=21); yy += 27
    yy += 22
    s.text(px, yy, "Outside of work", font="script", size=40, fill=OLIVE); yy += 34
    for ln in wrap(OUTSIDE, "italic", 21, pw):
        s.text(px, yy, ln, font="italic", size=21); yy += 27
    s.add(f'<g class="drift">{note(px + pw - 30, H - 52, 1.1, AMBER)}</g>')
    return s.save("about.svg")


def project(p, idx):
    W = 900
    c = p["color"]
    tag_lines = wrap(p["tag"], "italic", 23, 610)
    H = int(168 + len(tag_lines) * 28 + 100 + 58)
    s = SVG(W, H, f"{p['title']}, {p['sub']}: {p['tag']} " + "; ".join(f"{a} {b}" for a, b in p["stats"]) + f". {p['stack']}")
    s.css.append(ANIM)
    frame(s, W, H, fill=IVORY, inner=c)
    s.add(f'<rect x="9" y="9" width="6" height="{H - 18}" fill="{c}"/>')
    s.caps(46, 52, p["sub"], size=13, fill=c, spacing=2.8)
    s.text(44, 118, p["title"], font="script", size=72, fill=BROWN)
    tw = measure(p["title"], "script", 72)
    s.add(f'<line class="rule" x1="{50}" y1="136" x2="{50 + tw + 30}" y2="136" stroke="{c}" stroke-width="1.3"/>' + diamond(58 + tw + 34, 136, 4, c))
    ty = 172
    for ln in tag_lines:
        s.text(48, ty, ln, font="italic", size=23); ty += 28
    by, bw, bh = ty + 4, 192, 88
    for i, (num, lab) in enumerate(p["stats"]):
        x = 48 + i * (bw + 14)
        s.add(f'<rect x="{x}" y="{by}" width="{bw}" height="{bh}" rx="2" fill="{TINT[c]}" stroke="{c}" stroke-width="1"/>')
        s.text(x + bw / 2, by + 44, num, font="bold", size=36, fill=c, anchor="middle")
        for j, ln in enumerate(wrap(lab, "serif", 16.5, bw - 18)[:2]):
            s.text(x + bw / 2, by + 66 + j * 17, ln, size=16.5, anchor="middle")
    s.caps(48, by + bh + 38, p["stack"], size=12, fill=BROWN, spacing=1.6)
    ix, iy = 790, 120
    if p["icon"] == "mag":
        s.add(magnifier(ix, iy + 20, 42, TEAL))
        s.add(diamond(ix + 64, iy - 34, 5, AMBER, "glint") + diamond(ix - 62, iy - 18, 3.5, WINE, "glint"))
    elif p["icon"] == "piano":
        s.add(piano(ix - 74, iy, 148, 76))
        s.add(f'<g class="drift">{note(ix + 52, iy - 18, 1.0, WINE)}{note(ix - 44, iy - 26, 0.8, TEAL)}</g>')
    else:
        s.add(f'<path d="M{ix - 100},{iy + 80} C{ix - 60},{iy + 100} {ix - 46},{iy + 30} {ix - 4},{iy + 46}" fill="none" '
              f'stroke="{OLIVE}" stroke-width="1.3" stroke-dasharray="4 7" stroke-linecap="round" opacity="0.7"/>')
        s.add(f'<g class="drift">{plane(ix + 20, iy + 22, 1.5, OLIVE)}</g>')
    return s.save(f"project-{p['key']}.svg")


def timeline():
    W, colw = 900, 164
    blocks = []
    for yr, org, role, nt, c in JOBS:
        lines = [("caps", 14, yr, c), ("bold", 25, org, BROWN)]
        lines += [("italic", 19, ln, BROWN) for ln in wrap(role, "italic", 19, colw - 12)]
        lines += [("serif", 16.5, ln, BROWN) for ln in wrap(nt, "serif", 16.5, colw - 12)]
        blocks.append(lines)
    gap = lambda f, sz: sz + (10 if f == "caps" else 5)
    tot = [sum(gap(f, sz) for f, sz, _, _ in b) for b in blocks]
    mid = int(34 + max(tot[0::2]) + 34)
    H = int(mid + 36 + max(tot[1::2]) + 34)
    s = SVG(W, H, "Experience: " + "; ".join(f"{y}, {o}, {r}" for y, o, r, _, _ in JOBS))
    s.css.append(ANIM)
    frame(s, W, H)
    s.add(f'<line class="rule" x1="40" y1="{mid}" x2="860" y2="{mid}" stroke="{BROWN}" stroke-width="1.4"/>')
    s.add(diamond(40, mid, 4, AMBER) + diamond(866, mid, 5, WINE))
    for i, lines in enumerate(blocks):
        c = JOBS[i][4]
        cx = 40 + colw / 2 + i * colw
        s.add(f'<circle cx="{cx}" cy="{mid}" r="10" fill="{IVORY}" stroke="{c}" stroke-width="1.6"/><circle cx="{cx}" cy="{mid}" r="5" fill="{c}"/>')
        up = i % 2 == 0
        s.add(f'<line x1="{cx}" y1="{mid + (-12 if up else 12)}" x2="{cx}" y2="{mid + (-26 if up else 28)}" stroke="{c}" stroke-width="1"/>')
        y = (mid - 28 - tot[i]) if up else (mid + 32)
        for f, sz, t, col in lines:
            y += gap(f, sz)
            if f == "caps":
                s.caps(cx, y, t, size=sz, fill=col, anchor="middle", spacing=2.2)
            else:
                s.text(cx, y, t, font=f, size=sz, fill=col, anchor="middle")
    return s.save("experience.svg")


def toolbox():
    W = 900
    size, padx, gap, rowh = 19, 14, 10, 46
    left, right = 252, 862
    layout, y = [], 40
    for name, c, items in GROUPS:
        x, rows, row = left, [], []
        for it in items:
            w = measure(it, "serif", size) + padx * 2
            if x + w > right and row:
                rows.append(row); row = []; x = left
            row.append((it, x, w)); x += w + gap
        rows.append(row)
        layout.append((name, c, rows, y)); y += len(rows) * rowh + 28
    H = int(y + 8)
    s = SVG(W, H, "Toolkit: " + "; ".join(f"{n}: {', '.join(i)}" for n, _, i in GROUPS))
    frame(s, W, H)
    for gi, (name, c, rows, gy) in enumerate(layout):
        s.text(44, gy + 30, name, font="script", size=40, fill=c)
        for ri, row in enumerate(rows):
            for it, x, w in row:
                yy = gy + ri * rowh
                s.add(f'<rect x="{x:.1f}" y="{yy + 4}" width="{w:.1f}" height="34" rx="17" fill="{TINT[c]}" stroke="{c}" stroke-width="1"/>')
                s.text(x + w / 2, yy + 27, it, size=size, anchor="middle")
        if gi < len(layout) - 1:
            ly = gy + len(rows) * rowh + 12
            s.add(f'<line x1="44" y1="{ly}" x2="856" y2="{ly}" stroke="{AMBER}" stroke-width="0.8" stroke-opacity="0.6"/>')
    return s.save("toolbox.svg")


def button(key, label, color):
    w = int(measure(label.upper(), "bold", 15, 3)) + 64
    s = SVG(w + 4, 54, label)
    s.add(f'<rect x="2" y="2" width="{w}" height="50" rx="3" fill="{color}"/>')
    s.add(f'<rect x="7" y="7" width="{w - 10}" height="40" rx="2" fill="none" stroke="{CREAM}" stroke-width="0.9" stroke-opacity="0.7"/>')
    s.caps(2 + w / 2, 33, label, size=15, fill=CREAM, anchor="middle", spacing=3)
    return s.save(f"btn-{key}.svg")


def divider():
    s = SVG(900, 44, "divider")
    s.css.append(ANIM)
    s.add(flourish(450, 22, 560))
    return s.save("divider.svg")


def footer():
    W, H = 900, 180
    s = SVG(W, H, "Thank you for visiting. Let's build AI people can trust.")
    s.css.append(ANIM)
    frame(s, W, H)
    s.text(W / 2, 92, "Thank you for visiting", font="script", size=60, fill=BROWN, anchor="middle")
    s.add(flourish(W / 2, 114, 300))
    s.text(W / 2, 148, "Let's build AI people can trust.", font="italic", size=23, fill=TEAL, anchor="middle")
    return s.save("footer.svg")


if __name__ == "__main__":
    out = [header(), about(), timeline(), toolbox(), divider(), footer()]
    for k, l in HEADS:
        out += [heading(k, l, False), heading(k, l, True)]
    out += [project(p, i) for i, p in enumerate(PROJECTS)]
    out += [button("linkedin", "LinkedIn", TEAL), button("email", "Email", WINE), button("github", "Repositories", OLIVE)]
    for o in out:
        print(f"{os.path.getsize(o) / 1024:6.1f} KB  {o}")
