<p align="center">
  <img src="assets/header.svg" width="100%" alt="Aleena Benny. AI Engineer, LLM Agents, Evaluation. I build AI systems that have to prove they work. B.S. Computer Science, UNC Charlotte. Open to AI Engineer, Forward Deployed Engineer and Software Engineer roles." />
</p>

<p align="center">
  <a href="https://linkedin.com/in/aleena-benny-2a1830308"><img src="assets/btn-linkedin.svg" height="48" alt="LinkedIn" /></a>
  &nbsp;
  <a href="mailto:aabenny152@gmail.com"><img src="assets/btn-email.svg" height="48" alt="Email" /></a>
  &nbsp;
  <a href="https://github.com/aleenabenny0?tab=repositories"><img src="assets/btn-github.svg" height="48" alt="Repositories" /></a>
</p>

<br/>

<!-- ABOUT -->
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/main/assets/h-about-dark.svg" />
  <img src="assets/h-about-light.svg" width="100%" alt="About" />
</picture>

<img src="assets/about.svg" width="100%" alt="Computer Science graduate of UNC Charlotte (AI, Robotics & Gaming concentration; Security & Intelligence Studies minor). I design LLM agents and retrieval pipelines, and the evaluation systems that hold them accountable. Focused on AI that makes public services more reliable. AWS Certified AI Practitioner and Cloud Practitioner. Currently refining Agent Evals and seeking a full-time role in AI engineering. Outside of work: piano." />

<img src="assets/divider.svg" width="100%" alt="" />

<!-- PROJECTS -->
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/main/assets/h-built-dark.svg" />
  <img src="assets/h-built-light.svg" width="100%" alt="Selected Work" />
</picture>

<img src="assets/project-agent-evals.svg" width="100%" alt="Agent Evals: an LLM evaluation platform that grades AI agents. RAG agent beats a closed-book baseline by 37 points across 287 test cases; anomaly monitor caught 2 of 2 hidden faults. Python, Claude API, RAG, LLM-as-judge, PostgreSQL, GitHub Actions." />

<a href="https://github.com/aleenabenny0/arranger"><img src="assets/project-arranger.svg" width="100%" alt="Arranger: turns MIDI into playable two-hand piano sheet music. Playable arrangements for 14 of 20 pieces vs 6 for the baseline; 7-node LangGraph agent; at most 4 repair rounds per draft. Python, LangGraph, Claude API, FastAPI, PostgreSQL." /></a>

<a href="https://github.com/hkonain27/aeropredict-platform"><img src="assets/project-aeropredict.svg" width="100%" alt="AeroPredict: flight delay prediction from 7M+ flight records and 2 live weather APIs, deployed with Docker and Kubernetes on AWS EC2. Python, Flask, React, scikit-learn." /></a>

<img src="assets/divider.svg" width="100%" alt="" />

<!-- EXPERIENCE -->
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/main/assets/h-worked-dark.svg" />
  <img src="assets/h-worked-light.svg" width="100%" alt="Experience" />
</picture>

<img src="assets/experience.svg" width="100%" alt="Timeline: 2024 UNC Charlotte undergraduate research assistant; 2024-25 UNC Charlotte communication consultant and TA; 2025 City of Raleigh IT Data & Integrations intern; 2026 NC Department of IT Software QA Analyst intern (MCP server work, AI output evals, z/OS testing); 2026 to now DocsGPT open source contributor." />

<img src="assets/divider.svg" width="100%" alt="" />

<!-- TOOLBOX -->
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/main/assets/h-toolbox-dark.svg" />
  <img src="assets/h-toolbox-light.svg" width="100%" alt="Toolkit" />
</picture>

<img src="assets/toolbox.svg" width="100%" alt="AI: LLM agents, RAG, tool calling, MCP, embeddings, vector DBs, LLM evals, Claude API, LangGraph. Code: Python, TypeScript, JavaScript, SQL, FastAPI, Flask, React. Cloud: AWS, Docker, Kubernetes, PostgreSQL, GitHub Actions, Git." />

<img src="assets/divider.svg" width="100%" alt="" />

<!-- SNAKE (generated daily by .github/workflows/snake.yml) -->
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/main/assets/h-snake-dark.svg" />
  <img src="assets/h-snake-light.svg" width="100%" alt="Contributions" />
</picture>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/output/snake-dark.svg" />
    <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/output/snake.svg" />
    <img src="https://raw.githubusercontent.com/aleenabenny0/aleenabenny0/output/snake.svg" width="100%" alt="A snake eating my GitHub contribution graph" />
  </picture>
</p>

<br/>

<img src="assets/footer.svg" width="100%" alt="Thank you for visiting. Let's build AI people can trust." />
